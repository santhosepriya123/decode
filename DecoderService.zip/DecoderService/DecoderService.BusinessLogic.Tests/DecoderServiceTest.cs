using System;
using System.Collections.Generic;
using AutoFixture;
using DecoderService.BusinessLogic.Models;
using FluentAssertions;
using Xunit;

namespace DecoderService.BusinessLogic.Tests
{
    public class DecoderServiceTest : TestData
    {
        /// <summary>
        ///     GetDecodedValue_InvalidFormat_throwException
        /// </summary>
        [Theory]
        [InlineData("XX", "Unknown message format")]
        public void GetDecodedValue_InvalidFormat_throwException(string message, string expectedMessage)
        {
            // Arrange
            var service = new Services.DecoderService();

            // Act
            Action act = () => service.GetDecodedValue(message);

            // Assert
            act.ShouldThrow<Exception>().WithMessage(expectedMessage);
        }

        /// <summary>
        ///     GetDecodedValue_ValidMessage_BehavesAsExpected
        /// </summary>
        [Theory]
        [MemberData(nameof(GetDecodedValue_ValidMessage_BehavesAsExpected_Data))]
        public void GetDecodedValue_ValidMessage_BehavesAsExpected(string message,
            List<PayLoadInterpretation> expectedResult)
        {
            // Arrange
            var service = new Services.DecoderService();

            // Act
            var result = service.GetDecodedValue(message);

            // Assert
            expectedResult.Should().NotBeNull();
            result.ShouldBeEquivalentTo(expectedResult, o => o.ExcludingMissingMembers());
        }

        /// <summary>
        ///     GetPayLoadModels_InvalidData_throwException
        /// </summary>
        [Theory]
        [MemberData(nameof(GetPayLoadModels_InvalidData_throwException_Data))]
        public void GetPayLoadModels_InvalidData_throwException(List<byte> inputs, string expectedMessage)
        {
            // Arrange
            var service = new Services.DecoderService();

            // Act
            Action act = () => service.GetPayLoadModels(inputs);

            // Assert
            act.ShouldThrow<Exception>().WithMessage(expectedMessage);
        }

        /// <summary>
        ///     GetPayLoadModels_ValidMessage_BehavesAsExpected
        /// </summary>
        [Theory]
        [MemberData(nameof(GetPayLoadModels_ValidMessage_BehavesAsExpected_Data))]
        public void GetPayLoadModels_ValidMessage_BehavesAsExpected(List<byte> inputs,
            List<PayLoadModel> expectedResult)
        {
            // Arrange
            var service = new Services.DecoderService();

            // Act
            var result = service.GetPayLoadModels(inputs);

            // Assert
            expectedResult.Should().NotBeNull();
            result.ShouldBeEquivalentTo(expectedResult, o => o.ExcludingMissingMembers());
        }

        /// <summary>
        ///     GetPayLoadModels_InvalidData_throwException
        /// </summary>
        [Theory]
        [MemberData(nameof(GetInterpretations_InvalidData_throwException_Data))]
        public void GetInterpretations_InvalidData_throwException(List<PayLoadModel> payLoadModels,
            string expectedMessage)
        {
            // Arrange
            var service = new Services.DecoderService();

            // Act
            Action act = () => service.GetInterpretations(payLoadModels);

            // Assert
            act.ShouldThrow<Exception>().WithMessage(expectedMessage);
        }

        /// <summary>
        ///     GetPayLoadModels_ValidMessage_BehavesAsExpected
        /// </summary>
        [Theory]
        [MemberData(nameof(GetInterpretations_ValidMessage_BehavesAsExpected_Data))]
        public void GetInterpretations_ValidMessage_BehavesAsExpected(List<PayLoadModel> payLoadModels,
            List<PayLoadInterpretation> expectedResult)
        {
            // Arrange
            var service = new Services.DecoderService();

            // Act
            var result = service.GetInterpretations(payLoadModels);

            // Assert
            expectedResult.Should().NotBeNull();
            result.ShouldBeEquivalentTo(expectedResult, o => o.ExcludingMissingMembers());
        }
    }

    public class TestData : MockData
    {
        private static readonly IFixture Fixture = new Fixture();

        public static IEnumerable<object[]> GetPayLoadModels_InvalidData_throwException_Data()
        {
            yield return new object[]
            {
                new List<byte>
                {
                    1, 0
                },
                "Invalid Value"
            };

            yield return new object[]
            {
                new List<byte>
                {
                    1, 2, 3
                },
                "Incomplete Data"
            };
        }

        public static IEnumerable<object[]> GetInterpretations_ValidMessage_BehavesAsExpected_Data()
        {
            yield return new object[]
            {
                GetPayLoad(Fixture),
                GetPayLoadInterpretations(Fixture)
            };
        }

        public static IEnumerable<object[]> GetInterpretations_InvalidData_throwException_Data()
        {
            yield return new object[]
            {
                new List<PayLoadModel>
                {
                    Fixture.Build<PayLoadModel>()
                        .With(x => x.Type, 3)
                        .With(x => x.Length, 3)
                        .With(x => x.ValueBytes, new List<byte> {1, 2, 3, 4, 5}).Create()
                },

                "Incorrect software version format. Software version in the form [ Major, Minor, Revision ]"
            };

            yield return new object[]
            {
                new List<PayLoadModel>
                {
                    Fixture.Build<PayLoadModel>()
                        .With(x => x.Type, 4)
                        .With(x => x.Length, 1)
                        .With(x => x.ValueBytes, new List<byte> {6}).Create()
                },

                "Invalid Power Consumption"
            };
            yield return new object[]
            {
                new List<PayLoadModel>
                {
                    Fixture.Build<PayLoadModel>()
                        .With(x => x.Type, 4)
                        .With(x => x.Length, 1)
                        .With(x => x.ValueBytes, new List<byte> {6, 8}).Create()
                },

                "Invalid Power consumption"
            };

            yield return new object[]
            {
                new List<PayLoadModel>
                {
                    Fixture.Build<PayLoadModel>()
                        .With(x => x.Type, 5)
                        .With(x => x.Length, 16)
                        .With(x => x.ValueBytes, new List<byte> {254, 255, 255, 255, 45, 0, 13, 0, 24, 0, 0, 0, 98, 0})
                        .Create()
                },

                "Incomplete Data"
            };

            yield return new object[]
            {
                new List<PayLoadModel>
                {
                    Fixture.Build<PayLoadModel>()
                        .With(x => x.Type, 8)
                        .With(x => x.Length, 16)
                        .With(x => x.ValueBytes, new List<byte> {1, 2, 3, 4, 5}).Create()
                },

                "Invalid Pay Load Type"
            };
        }

        public static IEnumerable<object[]> GetPayLoadModels_ValidMessage_BehavesAsExpected_Data()
        {
            yield return new object[]
            {
                new List<byte>
                {
                    1, 2, 75, 8, 2, 6, 77, 45, 75, 79, 80, 65, 3, 3, 1, 2, 3, 4, 1, 2, 5, 16, 254, 255, 255, 255, 45, 0,
                    13, 0, 24, 0, 0, 0, 98, 0, 90, 0
                },
                GetPayLoad(Fixture)
            };
        }

        public static IEnumerable<object[]> GetDecodedValue_ValidMessage_BehavesAsExpected_Data()
        {
            yield return new object[]
            {
                "01024B0802064D2D4B4F504103030102030401020510FEFFFFFF2D000D001800000062005A00",
                GetPayLoadInterpretations(Fixture)
            };
        }
    }

    public class MockData
    {
        public static List<TelemetryModel> GeTelemetryModels(IFixture fixture)
        {
            return new List<TelemetryModel>
            {
                fixture.Build<TelemetryModel>()
                    .With(x => x.Temperature, -2)
                    .With(x => x.BatteryLevel, 45)
                    .With(x => x.SolarVoltage, 13).Create(),

                fixture.Build<TelemetryModel>()
                    .With(x => x.Temperature, 24)
                    .With(x => x.BatteryLevel, 98)
                    .With(x => x.SolarVoltage, 90).Create()
            };
        }

        public static List<PayLoadInterpretation> GetPayLoadInterpretations(IFixture fixture)
        {
            return new List<PayLoadInterpretation>
            {
                fixture.Build<PayLoadInterpretation>()
                    .With(x => x.Length, 2)
                    .With(x => x.Type, 1)
                    .With(x => x.PayLoadValues, 2123).Create(),

                fixture.Build<PayLoadInterpretation>()
                    .With(x => x.Type, 2)
                    .With(x => x.Length, 6)
                    .With(x => x.PayLoadValues, "M-KOPA").Create(),

                fixture.Build<PayLoadInterpretation>()
                    .With(x => x.Type, 3)
                    .With(x => x.Length, 3)
                    .With(x => x.PayLoadValues, (1, 2, 3)).Create(),

                fixture.Build<PayLoadInterpretation>()
                    .With(x => x.Type, 4)
                    .With(x => x.Length, 1)
                    .With(x => x.PayLoadValues, "NormalConsumption").Create(),

                fixture.Build<PayLoadInterpretation>()
                    .With(x => x.Type, 5)
                    .With(x => x.Length, 16)
                    .With(x => x.PayLoadValues, GeTelemetryModels(fixture)).Create()
            };
        }

        public static List<PayLoadModel> GetPayLoad(IFixture fixture)
        {
            return new List<PayLoadModel>
            {
                fixture.Build<PayLoadModel>()
                    .With(x => x.Length, 2)
                    .With(x => x.Type, 1)
                    .With(x => x.ValueBytes, new List<byte> {75, 8}).Create(),

                fixture.Build<PayLoadModel>()
                    .With(x => x.Type, 2)
                    .With(x => x.Length, 6)
                    .With(x => x.ValueBytes, new List<byte> {77, 45, 75, 79, 80, 65}).Create(),

                fixture.Build<PayLoadModel>()
                    .With(x => x.Type, 3)
                    .With(x => x.Length, 3)
                    .With(x => x.ValueBytes, new List<byte> {1, 2, 3}).Create(),

                fixture.Build<PayLoadModel>()
                    .With(x => x.Type, 4)
                    .With(x => x.Length, 1)
                    .With(x => x.ValueBytes, new List<byte> {2}).Create(),

                fixture.Build<PayLoadModel>()
                    .With(x => x.Type, 5)
                    .With(x => x.Length, 16)
                    .With(x => x.ValueBytes,
                        new List<byte> {254, 255, 255, 255, 45, 0, 13, 0, 24, 0, 0, 0, 98, 0, 90, 0}).Create()
            };
        }
    }
}