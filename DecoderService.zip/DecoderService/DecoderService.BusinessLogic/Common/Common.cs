﻿using System.ComponentModel;

namespace DecoderService.BusinessLogic.Common
{
    public enum PowerConsumption
    {
        [Description("Auto Mode")] AutoMode = 0,
        [Description("Low Consumption")] LowConsumption = 1,
        [Description("Normal Consumption")] NormalConsumption = 2,
        [Description("High Consumption")] HighConsumption = 3
    }
}