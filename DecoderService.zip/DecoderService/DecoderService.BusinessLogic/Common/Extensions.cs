﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace DecoderService.BusinessLogic.Common
{
    public static class Extensions
    {
        public static int ConvertToInt32(this List<byte> bytes)
        {
            return BitConverter.ToInt32(bytes.ToArray().ToBigEndian(), 0);
        }

        public static int ConvertToInt16(this List<byte> bytes)
        {
            var byteAry = bytes.ToArray().ToBigEndian();

            if (byteAry.Length < 2) // if array has 1 value then throw error
                Array.Resize(ref byteAry, 2);

            return BitConverter.ToInt16(byteAry, 0);
        }

        public static ushort ConvertToUInt16(this List<byte> bytes)
        {
            return BitConverter.ToUInt16(bytes.ToArray().ToBigEndian(), 0);
        }

        public static string ConvertToString(this List<byte> bytes)
        {
            var byteAry = bytes.ToArray().ToBigEndian();
            return Encoding.UTF8.GetString(byteAry, 0, byteAry.Length);
        }

        public static List<byte> ConvertToBytes(this string input)
        {
            return Enumerable.Range(0, input.Length)
                .Where(x => x % 2 == 0)
                .Select(x => Convert.ToByte(input.Substring(x, 2), 16))
                .ToList();
        }

        public static bool IsHex(this string input)
        {
            return Regex.IsMatch(input, @"\A\b[0-9a-fA-F]+\b\Z");
        }

        private static byte[] ToBigEndian(this byte[] bytes)
        {
            if (!BitConverter.IsLittleEndian)
                Array.Reverse(bytes);
            return bytes;
        }
    }
}