﻿using System.Collections.Generic;
using DecoderService.BusinessLogic.Models;

namespace DecoderService.BusinessLogic.Interfaces
{
    public interface IDecoderService
    {
        List<PayLoadInterpretation> GetDecodedValue(string message);
    }
}