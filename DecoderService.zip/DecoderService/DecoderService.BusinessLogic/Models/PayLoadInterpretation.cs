﻿namespace DecoderService.BusinessLogic.Models
{
    public class PayLoadInterpretation
    {
        public byte Type { get; set; }
        public int Length { get; set; }
        public dynamic PayLoadValues { get; set; }
    }
}