﻿using System.Collections.Generic;

namespace DecoderService.BusinessLogic.Models
{
    public class PayLoadModel
    {
        public byte Type { set; get; }
        public byte Length { set; get; }
        public List<byte> ValueBytes { set; get; }
    }
}