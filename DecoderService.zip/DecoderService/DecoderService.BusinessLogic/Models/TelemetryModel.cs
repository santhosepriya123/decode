﻿namespace DecoderService.BusinessLogic.Models
{
    public class TelemetryModel
    {
        public int Temperature { get; set; }
        public ushort BatteryLevel { get; set; }
        public ushort SolarVoltage { get; set; }
    }
}