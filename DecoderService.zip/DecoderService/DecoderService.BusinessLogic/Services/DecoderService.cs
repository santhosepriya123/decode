﻿using System;
using System.Collections.Generic;
using System.Linq;
using DecoderService.BusinessLogic.Common;
using DecoderService.BusinessLogic.Interfaces;
using DecoderService.BusinessLogic.Models;

namespace DecoderService.BusinessLogic.Services
{
    /// <summary>
    ///     Business logic class for decoder services
    /// </summary>
    public class DecoderService : IDecoderService
    {
        /// <summary>
        ///     Get decoded value
        /// </summary>
        public List<PayLoadInterpretation> GetDecodedValue(string message)
        {
            if (!message.IsHex()) throw new Exception("Unknown message format");

            var inputs = message.ConvertToBytes();

            var payLoads = GetPayLoadModels(inputs);

            return GetInterpretations(payLoads);
        }

        /// <summary>
        ///     Get pay load list
        /// </summary>
        public List<PayLoadModel> GetPayLoadModels(List<byte> inputs)
        {
            var payLoadModels = new List<PayLoadModel>();
            var i = 0;

            while (i < inputs.Count)
            {
                var type = inputs[i];
                var length = inputs[i + 1];

                i += 2;
                var lengthInInt = Convert.ToInt32(length);

                if (Convert.ToInt32(type) <= 0 || lengthInInt <= 0) throw new Exception("Invalid Value");

                if (i + lengthInInt > inputs.Count) throw new Exception("Incomplete Data");

                var payLoadModel = new PayLoadModel
                {
                    Type = type, Length = length, ValueBytes = inputs.Skip(i).Take(lengthInInt).ToList()
                };

                payLoadModels.Add(payLoadModel);
                i += lengthInInt;
            }

            return payLoadModels;
        }

        /// <summary>
        ///     Get pay load decoded values
        /// </summary>
        public List<PayLoadInterpretation> GetInterpretations(List<PayLoadModel> payLoadModels)
        {
            var payLoadInterpretations = new List<PayLoadInterpretation>();
            payLoadModels.ForEach(p =>
            {
                switch (p.Type)
                {
                    case 1:
                        payLoadInterpretations.Add(new PayLoadInterpretation
                        {
                            Length = p.Length,
                            Type = p.Type,
                            PayLoadValues = p.ValueBytes.ConvertToUInt16()
                        });
                        break;
                    case 2:
                        payLoadInterpretations.Add(new PayLoadInterpretation
                        {
                            Length = p.Length,
                            Type = p.Type,
                            PayLoadValues = p.ValueBytes.ConvertToString()
                        });
                        break;
                    case 3:
                        if (p.ValueBytes.Count != 3)
                            throw new Exception(
                                "Incorrect software version format. Software version in the form [ Major, Minor, Revision ]");

                        payLoadInterpretations.Add(new PayLoadInterpretation
                        {
                            Length = p.Length,
                            Type = p.Type,
                            PayLoadValues = GetSoftwareVersion(p.ValueBytes)
                        });
                        break;
                    case 4:
                        if (p.ValueBytes.Count != 1)
                            throw new Exception(
                                "Invalid Power consumption");

                        var enumValue = p.ValueBytes.ConvertToInt16();
                        if (enumValue > 3) throw new Exception("Invalid Power Consumption");
                        Enum.TryParse(enumValue.ToString(), out PowerConsumption powerConsumption);
                        payLoadInterpretations.Add(new PayLoadInterpretation
                        {
                            Length = p.Length,
                            Type = p.Type,
                            PayLoadValues = powerConsumption.ToString()
                        });
                        break;
                    case 5:
                        if (p.ValueBytes.Count % 8 != 0)
                            throw new Exception("Incomplete Data");

                        payLoadInterpretations.Add(new PayLoadInterpretation
                        {
                            Length = p.Length,
                            Type = p.Type,
                            PayLoadValues = GetTelemetryModel(p.ValueBytes)
                        });
                        break;
                    default:
                        throw new Exception("Invalid Pay Load Type");
                }
            });
            return payLoadInterpretations;
        }

        private static List<TelemetryModel> GetTelemetryModel(List<byte> input)
        {
            var telemetryModels = new List<TelemetryModel>();
            var i = 0;
            while (i < input.Count)
            {
                var temperature = input.Skip(i).Take(4).ToList();
                var battery = input.Skip(i + 4).Take(2).ToList();
                var solar = input.Skip(i + 6).Take(2).ToList();
                telemetryModels.Add(new TelemetryModel
                {
                    Temperature = temperature.ConvertToInt32(),
                    BatteryLevel = battery.ConvertToUInt16(),
                    SolarVoltage = solar.ConvertToUInt16()
                });
                i += 8;
            }

            return telemetryModels;
        }

        private static (int major, int minor, int revision) GetSoftwareVersion(List<byte> input)
        {
            var major = Convert.ToInt32(input[0]);
            var minor = Convert.ToInt32(input[1]);
            var revision = Convert.ToInt32(input[2]);
            return (major, minor, revision);
        }
    }
}