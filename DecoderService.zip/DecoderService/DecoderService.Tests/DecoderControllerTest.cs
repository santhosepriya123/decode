using System.Collections.Generic;
using System.Linq;
using AutoFixture;
using DecoderService.BusinessLogic.Interfaces;
using DecoderService.BusinessLogic.Models;
using DecoderService.Controllers;
using DecoderService.ResourceModel;
using FluentAssertions;
using Microsoft.AspNetCore.Mvc;
using Moq;
using Xunit;

namespace DecoderService.Tests
{
    public class DecoderControllerTest : TestData
    {
        private static void Validate(IActionResult result, List<DecodedResourceModel> externalData)
        {
            var data = result.Should().BeOfType<OkObjectResult>().Subject.Value;
            var castData = data.Should().BeOfType<List<DecodedResourceModel>>().Subject;

            castData.Should().ShouldBeEquivalentTo(externalData, o => o.ExcludingMissingMembers());
        }

        /// <summary>
        ///     Definitely this mapping should not come in realtime.
        /// </summary>
        private static List<DecodedResourceModel> Mapping(IEnumerable<PayLoadInterpretation> payLoad)
        {
            return payLoad?.Select(p => new DecodedResourceModel
            {
                Type = p.Type,
                Length = p.Length,
                PayLoadValues = p.PayLoadValues
            }).ToList();
        }

        [Fact]
        public void Decode_WithAutoData_BehavesAsExpected()
        {
            // Arrange
            const string message = "01024B0802064D2D4B4F504103030102030401020510FEFFFFFF2D000D001800000062005A00";
            var fixture = new Fixture();
            var expectedServiceResult = GetDecodedResourceModels(fixture);
            var mockDecoderService = fixture.Freeze<Mock<IDecoderService>>();
            mockDecoderService.Setup(m => m.GetDecodedValue(message)).Returns(expectedServiceResult);
            var controller = new DecoderController(mockDecoderService.Object);

            // Act
            var result = controller.Decode(message);

            //Verify
            Validate(result, Mapping(expectedServiceResult));
            mockDecoderService.Verify(s => s.GetDecodedValue(It.Is<string>(x => x == message)));
        }
    }

    public class TestData
    {
        public static List<PayLoadInterpretation> GetDecodedResourceModels(IFixture fixture)
        {
            var telemetryModels = new List<TelemetryModel>
            {
                fixture.Build<TelemetryModel>()
                    .With(x => x.Temperature, -2)
                    .With(x => x.BatteryLevel, 45)
                    .With(x => x.SolarVoltage, 13).Create(),

                fixture.Build<TelemetryModel>()
                    .With(x => x.Temperature, 24)
                    .With(x => x.BatteryLevel, 98)
                    .With(x => x.SolarVoltage, 90).Create()
            };

            return new List<PayLoadInterpretation>
            {
                fixture.Build<PayLoadInterpretation>()
                    .With(x => x.Length, 2)
                    .With(x => x.Type, 1)
                    .With(x => x.PayLoadValues, 2123).Create(),

                fixture.Build<PayLoadInterpretation>()
                    .With(x => x.Type, 2)
                    .With(x => x.Length, 6)
                    .With(x => x.PayLoadValues, "M-KOPA").Create(),

                fixture.Build<PayLoadInterpretation>()
                    .With(x => x.Type, 3)
                    .With(x => x.Length, 3)
                    .With(x => x.PayLoadValues, (1, 2, 3)).Create(),

                fixture.Build<PayLoadInterpretation>()
                    .With(x => x.Type, 4)
                    .With(x => x.Length, 1)
                    .With(x => x.PayLoadValues, "NormalConsumption").Create(),

                fixture.Build<PayLoadInterpretation>()
                    .With(x => x.Type, 5)
                    .With(x => x.Length, 16)
                    .With(x => x.PayLoadValues, telemetryModels).Create()
            };
        }
    }
}