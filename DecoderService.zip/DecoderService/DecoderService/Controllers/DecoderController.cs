﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Net;
using DecoderService.BusinessLogic.Interfaces;
using DecoderService.BusinessLogic.Models;
using DecoderService.ResourceModel;
using Microsoft.AspNetCore.Mvc;

namespace DecoderService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DecoderController : Controller
    {
        private readonly IDecoderService _decoderService;

        public DecoderController(IDecoderService decoderService)
        {
            _decoderService = decoderService;
        }

        /// <summary>
        ///     Get Decoded Values
        /// </summary>
        [HttpGet]
        [ProducesResponseType(typeof(List<DecodedResourceModel>), (int) HttpStatusCode.OK)]
        [ProducesResponseType((int) HttpStatusCode.BadRequest)]
        public IActionResult Decode([Required] string message)
        {
            if (string.IsNullOrWhiteSpace(message)) return BadRequest();

            var decodedModel = _decoderService.GetDecodedValue(message);

            return Ok(Mapping(decodedModel));
        }

        /// <summary>
        ///     We can replace by AutoMapper
        /// </summary>
        private static List<DecodedResourceModel> Mapping(IEnumerable<PayLoadInterpretation> payLoad)
        {
            return payLoad?.Select(p => new DecodedResourceModel
            {
                Type = p.Type,
                Length = p.Length,
                PayLoadValues = p.PayLoadValues
            }).ToList();
        }
    }
}