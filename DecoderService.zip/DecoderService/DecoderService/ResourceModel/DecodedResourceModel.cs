﻿namespace DecoderService.ResourceModel
{
    public class DecodedResourceModel
    {
        public byte Type { get; set; }
        public int Length { get; set; }
        public dynamic PayLoadValues { get; set; }
    }
}